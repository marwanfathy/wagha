'use client';

import React, { useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Loader2, Upload, X } from 'lucide-react';
import Navbar from '../components/Navbar/Navbar';
import { publicApi, mediaApi, setAccessToken, ApiRequestError } from '@/lib/api';
import '../globals.css';

const TOTAL_STEPS = 3;

const USERNAME_REGEX = /^[a-zA-Z0-9_.]+$/;
const PHONE_REGEX = /^\+?[1-9]\d{7,14}$/;

interface FormState {
  username: string;
  password: string;
  confirmPassword: string;
  fullName: string;
  phoneNumber: string;
  email: string;
  dateOfBirth: string;
  nationalIdNumber: string;
}

const initialForm: FormState = {
  username: '',
  password: '',
  confirmPassword: '',
  fullName: '',
  phoneNumber: '',
  email: '',
  dateOfBirth: '',
  nationalIdNumber: '',
};

function calculateAge(dob: string): number {
  if (!dob) return 0;
  const birth = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const hasHadBirthdayThisYear =
    today.getMonth() > birth.getMonth() ||
    (today.getMonth() === birth.getMonth() && today.getDate() >= birth.getDate());
  if (!hasHadBirthdayThisYear) age -= 1;
  return age;
}

/** One of the two ID-photo dropzones, with drag/click upload + live preview. */
function IdPhotoDropzone({
  label,
  previewUrl,
  isUploading,
  error,
  onSelectFile,
  onRemove,
}: {
  label: string;
  previewUrl: string | null;
  isUploading: boolean;
  error?: string;
  onSelectFile: (file: File) => void;
  onRemove: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (files: FileList | null) => {
    const file = files?.[0];
    if (file) onSelectFile(file);
  };

  return (
    <div>
      <div
        className={`id-upload-zone ${previewUrl ? 'id-upload-zone-filled' : ''} ${error ? 'id-upload-zone-error' : ''}`}
        onClick={() => !previewUrl && inputRef.current?.click()}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          handleFiles(e.dataTransfer.files);
        }}
      >
        {isUploading && (
          <div className="id-upload-uploading-overlay">
            <Loader2 className="loader-spinner" style={{ height: 24, width: 24, margin: 0 }} />
          </div>
        )}

        {previewUrl ? (
          <>
            <img src={previewUrl} alt={`${label} preview`} className="id-upload-preview" />
            <button
              type="button"
              className="id-upload-remove-btn"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              aria-label={`Remove ${label}`}
            >
              <X size={14} />
            </button>
          </>
        ) : (
          <>
            <Upload className="id-upload-icon" size={22} />
            <span className="id-upload-label">Click or drag {label.toLowerCase()} here</span>
          </>
        )}

        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="id-upload-input"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>
      <p className="id-upload-caption" style={{ color: error ? '#f87171' : 'rgba(255,255,255,0.6)' }}>
        {error || label}
      </p>
    </div>
  );
}

export default function SignupPage() {
  const router = useRouter();

  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormState>(initialForm);
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [banner, setBanner] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // ID photos: local preview + the uploaded URL once the media server returns one.
  const [frontPreview, setFrontPreview] = useState<string | null>(null);
  const [backPreview, setBackPreview] = useState<string | null>(null);
  const [frontUrl, setFrontUrl] = useState<string | null>(null);
  const [backUrl, setBackUrl] = useState<string | null>(null);
  const [frontUploading, setFrontUploading] = useState(false);
  const [backUploading, setBackUploading] = useState(false);
  const [idErrors, setIdErrors] = useState<{ front?: string; back?: string }>({});

  const updateField = (field: keyof FormState, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setFieldErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  function validateStep1(): boolean {
    const errors: Partial<Record<keyof FormState, string>> = {};
    if (form.username.length < 3 || form.username.length > 30 || !USERNAME_REGEX.test(form.username)) {
      errors.username = 'Username must be 3-30 characters: letters, numbers, dots, underscores only.';
    }
    if (form.password.length < 8) {
      errors.password = 'Password must be at least 8 characters.';
    } else if (!/[a-z]/.test(form.password) || !/[A-Z]/.test(form.password) || !/[0-9]/.test(form.password)) {
      errors.password = 'Password needs an uppercase letter, lowercase letter, and a number.';
    }
    if (form.confirmPassword !== form.password) {
      errors.confirmPassword = 'Passwords do not match.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function validateStep2(): boolean {
    const errors: Partial<Record<keyof FormState, string>> = {};
    if (form.fullName.trim().length < 2) {
      errors.fullName = 'Enter your full name.';
    }
    if (!PHONE_REGEX.test(form.phoneNumber)) {
      errors.phoneNumber = 'Enter a valid phone number, e.g. +201234567890.';
    }
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) {
      errors.email = 'Enter a valid email or leave it blank.';
    }
    if (!form.dateOfBirth) {
      errors.dateOfBirth = 'Date of birth is required.';
    } else if (calculateAge(form.dateOfBirth) < 18) {
      errors.dateOfBirth = 'You must be at least 18 years old to register.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function validateStep3(): boolean {
    const errors: { front?: string; back?: string } = {};
    if (form.nationalIdNumber.trim().length < 5) {
      setFieldErrors((prev) => ({ ...prev, nationalIdNumber: 'Enter your national ID number.' }));
    }
    if (!frontUrl) errors.front = 'Front photo is required.';
    if (!backUrl) errors.back = 'Back photo is required.';
    setIdErrors(errors);
    return form.nationalIdNumber.trim().length >= 5 && !errors.front && !errors.back;
  }

  const handleNext = () => {
    setBanner(null);
    if (step === 1 && validateStep1()) setStep(2);
    else if (step === 2 && validateStep2()) setStep(3);
  };

  const handleBack = () => {
    setBanner(null);
    setStep((s) => Math.max(1, s - 1));
  };

  async function uploadIdPhoto(file: File, side: 'front' | 'back') {
    const setUploading = side === 'front' ? setFrontUploading : setBackUploading;
    const setPreview = side === 'front' ? setFrontPreview : setBackPreview;
    const setUrl = side === 'front' ? setFrontUrl : setBackUrl;

    setIdErrors((prev) => ({ ...prev, [side]: undefined }));
    setPreview(URL.createObjectURL(file)); // instant local preview while it uploads
    setUploading(true);

    try {
      const { ticket } = await publicApi.requestIdVerificationTicket();
      const result = await mediaApi.uploadIdPhoto(file, ticket);
      setUrl(result.url);
    } catch (err) {
      const message = err instanceof ApiRequestError ? err.message : 'Upload failed, try again.';
      setIdErrors((prev) => ({ ...prev, [side]: message }));
      setPreview(null);
      setUrl(null);
    } finally {
      setUploading(false);
    }
  }

  function removeIdPhoto(side: 'front' | 'back') {
    (side === 'front' ? setFrontPreview : setBackPreview)(null);
    (side === 'front' ? setFrontUrl : setBackUrl)(null);
  }

  async function handleSubmit() {
    setBanner(null);
    if (!validateStep3()) return;

    setIsSubmitting(true);
    try {
      const result = await publicApi.register({
        username: form.username.trim(),
        phoneNumber: form.phoneNumber.trim(),
        fullName: form.fullName.trim(),
        email: form.email.trim() || undefined,
        password: form.password,
        nationalIdNumber: form.nationalIdNumber.trim(),
        nationalIdPicFront: frontUrl as string,
        nationalIdPicBack: backUrl as string,
        dateOfBirth: form.dateOfBirth,
        role: 'CUSTOMER',
      });
      setAccessToken(result.accessToken);
      localStorage.setItem('accessToken', result.accessToken);
      localStorage.setItem('user', JSON.stringify(result.user));
      router.push('/');
    } catch (err) {
      const message = err instanceof ApiRequestError ? err.message : 'Could not create your account. Try again.';
      setBanner(message);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main style={{ position: 'relative', minHeight: '100vh', width: '100%' }}>
      <Navbar />

      <div className="auth-page">
        <div className={`auth-card ${step === 3 ? 'auth-card-wide' : ''}`}>
          <div className="auth-step-indicator">
            {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
              <div
                key={i}
                className={`auth-step-dot ${
                  i + 1 === step ? 'auth-step-dot-active' : i + 1 < step ? 'auth-step-dot-done' : ''
                }`}
              />
            ))}
          </div>

          {step === 1 && (
            <>
              <h1 className="auth-title">Create your account</h1>
              <p className="auth-subtitle">Step 1 of 3 — pick a username and password.</p>

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="username">Username</label>
                <input
                  id="username"
                  className={`auth-input ${fieldErrors.username ? 'auth-input-error' : ''}`}
                  type="text"
                  placeholder="yourusername"
                  value={form.username}
                  onChange={(e) => updateField('username', e.target.value)}
                  autoComplete="username"
                />
                {fieldErrors.username && <span className="auth-error-text">{fieldErrors.username}</span>}
              </div>

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="password">Password</label>
                <input
                  id="password"
                  className={`auth-input ${fieldErrors.password ? 'auth-input-error' : ''}`}
                  type="password"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={(e) => updateField('password', e.target.value)}
                  autoComplete="new-password"
                />
                {fieldErrors.password && <span className="auth-error-text">{fieldErrors.password}</span>}
              </div>

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="confirmPassword">Confirm password</label>
                <input
                  id="confirmPassword"
                  className={`auth-input ${fieldErrors.confirmPassword ? 'auth-input-error' : ''}`}
                  type="password"
                  placeholder="••••••••"
                  value={form.confirmPassword}
                  onChange={(e) => updateField('confirmPassword', e.target.value)}
                  autoComplete="new-password"
                />
                {fieldErrors.confirmPassword && <span className="auth-error-text">{fieldErrors.confirmPassword}</span>}
              </div>

              <div className="auth-step-actions">
                <button className="auth-submit-btn" type="button" onClick={handleNext}>Continue</button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h1 className="auth-title">Tell us about you</h1>
              <p className="auth-subtitle">Step 2 of 3 — your personal details.</p>

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="fullName">Full name</label>
                <input
                  id="fullName"
                  className={`auth-input ${fieldErrors.fullName ? 'auth-input-error' : ''}`}
                  type="text"
                  placeholder="Jane Doe"
                  value={form.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  autoComplete="name"
                />
                {fieldErrors.fullName && <span className="auth-error-text">{fieldErrors.fullName}</span>}
              </div>

              <div className="auth-row-two">
                <div className="auth-field-group">
                  <label className="auth-label" htmlFor="phoneNumber">Phone number</label>
                  <input
                    id="phoneNumber"
                    className={`auth-input ${fieldErrors.phoneNumber ? 'auth-input-error' : ''}`}
                    type="tel"
                    placeholder="+201234567890"
                    value={form.phoneNumber}
                    onChange={(e) => updateField('phoneNumber', e.target.value)}
                    autoComplete="tel"
                  />
                  {fieldErrors.phoneNumber && <span className="auth-error-text">{fieldErrors.phoneNumber}</span>}
                </div>

                <div className="auth-field-group">
                  <label className="auth-label" htmlFor="dateOfBirth">Date of birth</label>
                  <input
                    id="dateOfBirth"
                    className={`auth-input ${fieldErrors.dateOfBirth ? 'auth-input-error' : ''}`}
                    type="date"
                    value={form.dateOfBirth}
                    onChange={(e) => updateField('dateOfBirth', e.target.value)}
                  />
                  {fieldErrors.dateOfBirth && <span className="auth-error-text">{fieldErrors.dateOfBirth}</span>}
                </div>
              </div>

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="email">Email (optional)</label>
                <input
                  id="email"
                  className={`auth-input ${fieldErrors.email ? 'auth-input-error' : ''}`}
                  type="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  autoComplete="email"
                />
                {fieldErrors.email && <span className="auth-error-text">{fieldErrors.email}</span>}
              </div>

              <div className="auth-step-actions">
                <button className="auth-ghost-btn" type="button" onClick={handleBack}>Back</button>
                <button className="auth-submit-btn" type="button" onClick={handleNext}>Continue</button>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <h1 className="auth-title">Verify your identity</h1>
              <p className="auth-subtitle">Step 3 of 3 — this keeps the community safe and stays private.</p>

              {banner && <div className="auth-banner-error">{banner}</div>}

              <div className="auth-field-group">
                <label className="auth-label" htmlFor="nationalIdNumber">National ID number</label>
                <input
                  id="nationalIdNumber"
                  className={`auth-input ${fieldErrors.nationalIdNumber ? 'auth-input-error' : ''}`}
                  type="text"
                  placeholder="e.g. 29801011234567"
                  value={form.nationalIdNumber}
                  onChange={(e) => updateField('nationalIdNumber', e.target.value)}
                />
                {fieldErrors.nationalIdNumber && (
                  <span className="auth-error-text">{fieldErrors.nationalIdNumber}</span>
                )}
              </div>

              <div className="id-upload-grid">
                <IdPhotoDropzone
                  label="Front of ID"
                  previewUrl={frontPreview}
                  isUploading={frontUploading}
                  error={idErrors.front}
                  onSelectFile={(file) => uploadIdPhoto(file, 'front')}
                  onRemove={() => removeIdPhoto('front')}
                />
                <IdPhotoDropzone
                  label="Back of ID"
                  previewUrl={backPreview}
                  isUploading={backUploading}
                  error={idErrors.back}
                  onSelectFile={(file) => uploadIdPhoto(file, 'back')}
                  onRemove={() => removeIdPhoto('back')}
                />
              </div>

              <div className="auth-step-actions">
                <button className="auth-ghost-btn" type="button" onClick={handleBack} disabled={isSubmitting}>
                  Back
                </button>
                <button
                  className="auth-submit-btn"
                  type="button"
                  onClick={handleSubmit}
                  disabled={isSubmitting || frontUploading || backUploading}
                >
                  {isSubmitting ? (
                    <Loader2 className="loader-spinner" style={{ height: 18, width: 18, margin: 0 }} />
                  ) : (
                    'Create account'
                  )}
                </button>
              </div>
            </>
          )}

          {step === 1 && (
            <p className="auth-footer-text">
              Already have an account?{' '}
              <Link href="/login" className="auth-footer-link">Log in</Link>
            </p>
          )}
        </div>
      </div>
    </main>
  );
}