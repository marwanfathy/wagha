'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Loader2 } from 'lucide-react';
import Navbar from '../components/Navbar/Navbar';
import { publicApi, setAccessToken, ApiRequestError } from '@/lib/api';
import '../globals.css';

export default function LoginPage() {
  const router = useRouter();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  console.log("1. Form submitted"); // Check this
  setError(null);

  setIsSubmitting(true);
  try {
    console.log("2. Attempting API call...");
    const result = await publicApi.login({ identifier: username, password });
    
    console.log("3. API Result received:", result);
    
    setAccessToken(result.accessToken);
    localStorage.setItem('accessToken', result.accessToken);
    localStorage.setItem('user', JSON.stringify(result.user));

    console.log("4. Redirecting...");
    router.push('/');
  } catch (err) {
    console.error("API Error Object:", err); // Check this
    setError("Failed to connect to server.");
  } finally {
    setIsSubmitting(false);
  }
};
  return (
    <main style={{ position: 'relative', minHeight: '100vh', width: '100%' }}>
      <Navbar />

      <div className="auth-page">
        <div className="auth-card">
          <h1 className="auth-title">Welcome back</h1>
          <p className="auth-subtitle">Log in to continue planning your next stay.</p>

          {error && <div className="auth-banner-error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="auth-field-group">
              <label className="auth-label" htmlFor="username">Username</label>
              <input
                id="username"
                className="auth-input"
                type="text"
                placeholder="yourusername"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
              />
            </div>

            <div className="auth-field-group">
              <label className="auth-label" htmlFor="password">Password</label>
              <input
                id="password"
                className="auth-input"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
              />
            </div>

            <button className="auth-submit-btn" type="submit" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="loader-spinner" style={{ height: 18, width: 18, margin: 0 }} /> : 'Log in'}
            </button>
          </form>

          <p className="auth-footer-text">
            Don&apos;t have an account?{' '}
            <Link href="/signup" className="auth-footer-link">Sign up</Link>
          </p>
        </div>
      </div>
    </main>
  );
}