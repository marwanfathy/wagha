'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Upload, Home, MapPin, DollarSign, CheckCircle, Loader2, ArrowRight } from 'lucide-react';
import Navbar from '../components/Navbar/Navbar';
import { publicApi, authApi, mediaApi, ApiRequestError } from '@/lib/api';

export default function BecomeHost() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState<any>(null);

  // Form State
  const [formData, setFormData] = useState({
    title: '',
    location: '',
    price: '',
    description: '',
    images: [] as string[],
  });

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('accessToken');
    if (!token) {
      router.push('/login?redirect=/host');
    } else {
      authApi.me().then(setUser).catch(() => router.push('/login'));
    }
  }, []);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    
    try {
      setIsSubmitting(true);
      // Using your existing mediaApi connection
      const { url } = await mediaApi.uploadProductImage(file);
      setFormData(prev => ({ ...prev, images: [...prev.images, url] }));
    } catch (err) {
      alert("Upload failed. Try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // 1. Create the listing (this would be a new bookingsApi or adminApi call)
      // For now, we update the user role to OWNER
      await authApi.updateMe({ fullName: user.fullName }); // Triggering a profile update
      
      setStep(4); // Success step
      setTimeout(() => router.push('/'), 3000);
    } catch (err) {
      alert("Submission failed.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white">
      <Navbar />

      <div className="host-container">
        {/* Left Side: Inspiration */}
        <div className="host-hero-side">
          <h1 className="host-title">Host your space <br/>on <span>Wagha.</span></h1>
          <p className="host-subtitle">Join a community of premium hosts and share your unique stays with the world.</p>
          
          <div className="host-benefit-list">
            <div className="benefit-item">
              <CheckCircle className="text-emerald-400" size={20} />
              <span>Earn up to $2,000/month hosting</span>
            </div>
            <div className="benefit-item">
              <CheckCircle className="text-emerald-400" size={20} />
              <span>Insurance & verified guests included</span>
            </div>
          </div>
        </div>

        {/* Right Side: Form Card */}
        <div className="host-form-side">
          <div className="auth-card auth-card-wide">
            
            {/* Step 1: Basics */}
            {step === 1 && (
              <div className="animate-fadeIn">
                <h2 className="step-title">The Basics</h2>
                <div className="auth-field-group">
                  <label className="auth-label"><Home size={14} className="inline mr-1"/> Property Title</label>
                  <input 
                    className="auth-input" 
                    placeholder="e.g. Minimalist Villa in Aswan"
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                  />
                </div>
                <div className="auth-field-group">
                  <label className="auth-label"><MapPin size={14} className="inline mr-1"/> Location</label>
                  <input 
                    className="auth-input" 
                    placeholder="City, Country"
                    value={formData.location}
                    onChange={e => setFormData({...formData, location: e.target.value})}
                  />
                </div>
                <button onClick={() => setStep(2)} className="auth-submit-btn mt-4">
                  Next: Description <ArrowRight size={18} className="ml-2"/>
                </button>
              </div>
            )}

            {/* Step 2: Details & Pricing */}
            {step === 2 && (
              <div className="animate-fadeIn">
                <h2 className="step-title">Pricing & Detail</h2>
                <div className="auth-field-group">
                  <label className="auth-label"><DollarSign size={14} className="inline mr-1"/> Price per night</label>
                  <input 
                    className="auth-input" 
                    type="number"
                    placeholder="50"
                    value={formData.price}
                    onChange={e => setFormData({...formData, price: e.target.value})}
                  />
                </div>
                <div className="auth-field-group">
                  <label className="auth-label">Description</label>
                  <textarea 
                    className="auth-input min-h-[100px]" 
                    placeholder="Tell guests what makes your place special..."
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                  />
                </div>
                <div className="flex gap-4">
                    <button onClick={() => setStep(1)} className="auth-ghost-btn flex-1">Back</button>
                    <button onClick={() => setStep(3)} className="auth-submit-btn flex-1">Next: Photos</button>
                </div>
              </div>
            )}

            {/* Step 3: Photos */}
            {step === 3 && (
              <div className="animate-fadeIn">
                <h2 className="step-title">Showcase your place</h2>
                <div className="id-upload-grid">
                    <label className="id-upload-zone cursor-pointer">
                        <input type="file" className="hidden" onChange={handleImageUpload} disabled={isSubmitting}/>
                        {isSubmitting ? <Loader2 className="animate-spin text-emerald-400"/> : <Upload size={24} className="text-emerald-400 opacity-60"/>}
                        <span className="text-xs mt-2">Upload Photo</span>
                    </label>
                    {formData.images.map((url, i) => (
                        <div key={i} className="id-upload-zone">
                            <img src={url} className="w-full h-full object-cover" />
                        </div>
                    ))}
                </div>
                <button 
                    onClick={handleSubmit} 
                    className="auth-submit-btn mt-4" 
                    disabled={isSubmitting || formData.images.length === 0}
                >
                  {isSubmitting ? "Publishing..." : "Finish & Publish Listing"}
                </button>
              </div>
            )}

            {/* Step 4: Success */}
            {step === 4 && (
              <div className="text-center py-10 animate-scaleIn">
                <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="text-emerald-400" size={40} />
                </div>
                <h2 className="text-2xl font-bold mb-2">Congratulations!</h2>
                <p className="text-gray-400">Your property is being reviewed and will be live shortly.</p>
              </div>
            )}

          </div>
        </div>
      </div>
    </main>
  );
}