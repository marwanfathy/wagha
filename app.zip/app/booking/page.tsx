"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  Smartphone, CreditCard, Upload,
  X, Loader2, ChevronLeft, Wallet, Check
} from 'lucide-react';

// API Imports from your api.ts
import {
  authApi,
  bookingsApi,
  publicApi,
  mediaApi,
  paymentsApi,
  ApiRequestError
} from '@/lib/api';

// CSS Module Import
import styles from './BookingPage.module.css';

const TRIP_ID = "sinai-expedition-2024";
const PRICE_PER_PERSON = 1850;
const CHECK_IN = "2024-10-12";
const CHECK_OUT = "2024-10-19";

export default function BookingPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Data States ---
  const [user, setUser] = useState<any>(null);
  const [guests, setGuests] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<'instapay' | 'ewallet'>('instapay');
  const [paymentOption, setPaymentOption] = useState<'deposit' | 'full'>('full');

  // --- Media & UI States ---
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
  const [receiptUrl, setReceiptUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Calculations
  const totalTripPrice = guests * PRICE_PER_PERSON;
  const amountToPayNow = paymentOption === 'deposit' ? totalTripPrice / 2 : totalTripPrice;

  const stepsComplete =
    1 /* dates are always set */ +
    1 /* plan always has a default */ +
    1 /* method always has a default */ +
    (receiptUrl ? 1 : 0);

  useEffect(() => {
    async function loadProfile() {
      try {
        const profile = await authApi.me();
        setUser(profile);
      } catch (err) {
        router.push('/login?redirect=/booking');
      } finally {
        setIsLoading(false);
      }
    }
    loadProfile();
  }, [router]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setReceiptPreview(URL.createObjectURL(file));
    setIsUploading(true);
    setError(null);

    try {
      const { ticket } = await publicApi.requestIdVerificationTicket();
      const result = await mediaApi.uploadProductImage(file, ticket);
      setReceiptUrl(result.url);
    } catch (err) {
      setError("Failed to upload screenshot. Please try again.");
      setReceiptPreview(null);
    } finally {
      setIsUploading(false);
    }
  };

  const handleFinalSubmit = async () => {
    if (!receiptUrl) {
      setError("Please upload the payment screenshot to proceed.");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const booking: any = await bookingsApi.create({
        listingId: TRIP_ID,
        checkIn: CHECK_IN,
        checkOut: CHECK_OUT,
      });

      const bookingId = booking?.id;
      if (!bookingId) {
        throw new ApiRequestError("Booking was created but no ID was returned.", 500);
      }

      await paymentsApi.submitProof({
        bookingId,
        screenshotUrl: receiptUrl,
        transactionNumber: `TRX_${Date.now()}`,
        amountFoundInPic: amountToPayNow,
        transferDateTime: new Date().toISOString(),
      });

      router.push('/booking/success');
    } catch (err) {
      if (err instanceof ApiRequestError) {
        setError(err.message);
      } else {
        setError("An error occurred during booking.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className={styles.loadingPage}>
        <Loader2 size={28} className={styles.spinner} style={{ color: '#34D399' }} />
      </div>
    );
  }

  return (
    <main className={styles.main}>
      <div className={styles.page}>
        <div className={styles.card}>

          <button onClick={() => router.back()} className={styles.backBtn}>
            <ChevronLeft size={16} /> Back
          </button>

          {/* Progress rail */}
          <div className={styles.railWrap}>
            <div className={styles.railLabelRow}>
              <span className={styles.railTitle}>Sinai Expedition</span>
              <span className={styles.railFraction}>{stepsComplete}/4</span>
            </div>
            <div className={styles.railTrack}>
              <div 
                className={styles.railFill} 
                style={{ width: `${(stepsComplete / 4) * 100}%` }} 
              />
              {['Dates', 'Plan', 'Method', 'Proof'].map((label, i) => (
                <div
                  key={label}
                  className={styles.railStop}
                  style={{
                    left: `${(i / 3) * 100}%`,
                    background: i < stepsComplete ? '#34D399' : '#2A2A2A',
                    borderColor: i < stepsComplete ? '#34D399' : 'rgba(255,255,255,0.18)',
                  }}
                >
                  {i < stepsComplete && <Check size={10} strokeWidth={3} color="#0A0A0A" />}
                </div>
              ))}
            </div>
            <div className={styles.railLabels}>
              <span>Dates</span>
              <span>Plan</span>
              <span>Method</span>
              <span>Proof</span>
            </div>
          </div>

          {error && <div className={styles.errorBanner}>{error}</div>}

          <div className={styles.grid}>

            {/* FORM COLUMN */}
            <div className={styles.colForm}>

              {/* Profile */}
              <div className={styles.profileRow}>
                <div className={styles.avatar}>
                  <span className={styles.avatarInitial}>{user?.username?.[0]?.toUpperCase()}</span>
                </div>
                <div>
                  <p className={styles.profileName}>{user?.fullName}</p>
                  <p className={styles.profilePhone}>{user?.phoneNumber}</p>
                </div>
              </div>

              {/* Trip dates */}
              <section className={styles.section}>
                <p className={styles.sectionLabel}>Travel dates</p>
                <div className={styles.dateRow}>
                  <div className={styles.dateBlock}>
                    <span className={styles.dateCaption}>Check-in</span>
                    <span className={styles.dateValue}>Oct 12</span>
                  </div>
                  <div className={styles.dateDivider} />
                  <div className={styles.dateBlock}>
                    <span className={styles.dateCaption}>Check-out</span>
                    <span className={styles.dateValue}>Oct 19</span>
                  </div>
                  <div className={styles.nightsChip}>7 nights</div>
                </div>
              </section>

              {/* Guests */}
              <section className={styles.section}>
                <p className={styles.sectionLabel}>Total guests</p>
                <div className={styles.guestRow}>
                  <button
                    onClick={() => setGuests(Math.max(1, guests - 1))}
                    className={styles.stepperBtn}
                    aria-label="Decrease guests"
                  >
                    −
                  </button>
                  <span className={styles.guestCount}>{guests}</span>
                  <button
                    onClick={() => setGuests(guests + 1)}
                    className={styles.stepperBtn}
                    aria-label="Increase guests"
                  >
                    +
                  </button>
                  <span className={styles.guestHint}>{guests === 1 ? 'traveler' : 'travelers'}</span>
                </div>
              </section>

              {/* Payment Plan */}
              <section className={styles.section}>
                <p className={styles.sectionLabel}>Payment plan</p>
                <div className={styles.choiceRow}>
                  <button
                    onClick={() => setPaymentOption('full')}
                    className={`${styles.choiceCard} ${paymentOption === 'full' ? styles.choiceCardActive : ''}`}
                  >
                    <span className={`${styles.choiceIconWrap} ${paymentOption === 'full' ? styles.choiceIconWrapActive : ''}`}>
                      <Check size={14} strokeWidth={3} color={paymentOption === 'full' ? '#0A0A0A' : 'rgba(255,255,255,0.3)'} />
                    </span>
                    <span className={styles.choiceTextWrap}>
                      <span className={styles.choiceTitle}>Full price</span>
                      <span className={styles.choiceSub}>Pay 100% now</span>
                    </span>
                  </button>
                  <button
                    onClick={() => setPaymentOption('deposit')}
                    className={`${styles.choiceCard} ${paymentOption === 'deposit' ? styles.choiceCardActive : ''}`}
                  >
                    <span className={`${styles.choiceIconWrap} ${paymentOption === 'deposit' ? styles.choiceIconWrapActive : ''}`}>
                      <Wallet size={14} color={paymentOption === 'deposit' ? '#0A0A0A' : 'rgba(255,255,255,0.3)'} />
                    </span>
                    <span className={styles.choiceTextWrap}>
                      <span className={styles.choiceTitle}>Deposit</span>
                      <span className={styles.choiceSub}>Pay 50% to secure</span>
                    </span>
                  </button>
                </div>
              </section>

              {/* Payment Method */}
              <section className={styles.section}>
                <p className={styles.sectionLabel}>Payment method</p>
                <div className={styles.choiceRow}>
                  <button
                    onClick={() => setPaymentMethod('instapay')}
                    className={`${styles.methodCard} ${paymentMethod === 'instapay' ? styles.choiceCardActive : ''}`}
                  >
                    <Smartphone size={16} color={paymentMethod === 'instapay' ? '#34D399' : 'rgba(255,255,255,0.5)'} />
                    <span className={styles.methodLabel}>Instapay</span>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('ewallet')}
                    className={`${styles.methodCard} ${paymentMethod === 'ewallet' ? styles.choiceCardActive : ''}`}
                  >
                    <CreditCard size={16} color={paymentMethod === 'ewallet' ? '#34D399' : 'rgba(255,255,255,0.5)'} />
                    <span className={styles.methodLabel}>E-Wallet</span>
                  </button>
                </div>
              </section>
            </div>

            {/* PAYMENT COLUMN */}
            <div className={styles.colPay}>

              <div className={styles.transferCard}>
                <p className={styles.transferLabel}>Transfer exactly</p>
                <h2 className={styles.transferAmount}>
                  {amountToPayNow.toLocaleString()} <span className={styles.transferCurrency}>EGP</span>
                </h2>
                <div className={styles.transferDivider} />
                <p className={styles.transferTarget}>
                  To{' '}
                  <span className={styles.transferTargetValue}>
                    {paymentMethod === 'instapay' ? 'wagha.exp@instapay' : '01012345678'}
                  </span>
                </p>
              </div>

              <div
                className={`${styles.uploadZone} ${receiptPreview ? styles.uploadZoneFilled : ''}`}
                onClick={() => !receiptPreview && fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
              >
                {isUploading && (
                  <div className={styles.uploadOverlay}>
                    <Loader2 size={22} className={styles.spinner} style={{ color: '#34D399' }} />
                  </div>
                )}
                {receiptPreview ? (
                  <>
                    <img src={receiptPreview} className={styles.uploadPreviewImg} alt="Payment receipt preview" />
                    <button
                      className={styles.uploadRemoveBtn}
                      onClick={(e) => {
                        e.stopPropagation();
                        setReceiptPreview(null);
                        setReceiptUrl(null);
                      }}
                      aria-label="Remove screenshot"
                    >
                      <X size={14} />
                    </button>
                  </>
                ) : (
                  <div className={styles.uploadEmptyState}>
                    <Upload size={24} color="rgba(255,255,255,0.4)" />
                    <p className={styles.uploadTitle}>Upload receipt</p>
                    <p className={styles.uploadHint}>Screenshot must show amount and date</p>
                  </div>
                )}
                <input ref={fileInputRef} type="file" hidden onChange={handleFileUpload} accept="image/*" />
              </div>

              {/* Summary */}
              <div className={styles.summaryCard}>
                <div className={styles.summaryRow}>
                  <span className={styles.summaryLabel}>{guests} {guests === 1 ? 'guest' : 'guests'} × {PRICE_PER_PERSON.toLocaleString()}</span>
                  <span className={styles.summaryValue}>{totalTripPrice.toLocaleString()} EGP</span>
                </div>
                {paymentOption === 'deposit' && (
                  <div className={styles.summaryRow}>
                    <span className={styles.summaryLabelMuted}>Deposit (50%)</span>
                    <span className={styles.summaryValueMuted}>−{(totalTripPrice / 2).toLocaleString()} EGP</span>
                  </div>
                )}
                <div className={styles.summaryTotalRow}>
                  <span className={styles.summaryTotalLabel}>Due now</span>
                  <span className={styles.summaryTotalValue}>{amountToPayNow.toLocaleString()} EGP</span>
                </div>

                <button
                  disabled={isSubmitting || !receiptUrl}
                  onClick={handleFinalSubmit}
                  className={`${styles.submitBtn} ${isSubmitting || !receiptUrl ? styles.submitBtnDisabled : ''}`}
                >
                  {isSubmitting ? (
                    <Loader2 size={18} className={styles.spinner} />
                  ) : (
                    'Complete booking'
                  )}
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>
    </main>
  );
}