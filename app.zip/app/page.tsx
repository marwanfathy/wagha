'use client';

import React from 'react';
import Navbar from './components/Navbar/Navbar';
import Banner from './components/banner-landing/banner-lan';
import  SinaiJourney from './components/SinaiJourney.module/SinaiJourney.module'
export default function LandingPage() {
  return (
    <main style={{ position: 'relative', minHeight: '100vh', width: '100%', overflow: 'hidden' }}>
      <Navbar />
      <Banner />
      <SinaiJourney />
    </main>
  );
}