'use client';

import React, { useEffect, useRef, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { publicApi, type Slide, ApiRequestError } from '@/lib/api';

// How long each slide stays up before auto-advancing.
const AUTO_ADVANCE_MS = 6000;
// How long the cross-fade transition between slides takes — MUST match
// --transition-slow (700ms) in globals.css, since .hero-bg-transitioning and
// .hero-title-transitioning both key off that variable. If that duration
// changes, this needs to change with it.
const TRANSITION_MS = 700;

export default function Banner() {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch slides from the public marketing endpoint once on mount.
  useEffect(() => {
    let cancelled = false;

    async function loadSlides() {
      try {
        setIsLoading(true);
        setError(null);

        const data = await publicApi.getHeroSlides();
        if (!cancelled) {
          setSlides(data ?? []);
        }
      } catch (err) {
        console.error('Failed to load hero slides.', err);
        if (!cancelled) {
          const message = err instanceof ApiRequestError ? err.message : 'Unable to load banner content right now.';
          setError(message);
        }
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    loadSlides();
    return () => {
      cancelled = true;
    };
  }, []);

  const goToNextSlide = () => {
    if (slides.length < 2) return; // nothing to rotate to
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentIdx((prev: number) => (prev + 1) % slides.length);
      setIsTransitioning(false);
    }, TRANSITION_MS);
  };

  // Auto-advance on a timer, resetting whenever the slide changes.
  useEffect(() => {
    if (slides.length < 2) return;

    timerRef.current = setTimeout(goToNextSlide, AUTO_ADVANCE_MS);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentIdx, slides.length]);

  if (isLoading) {
    return <div className="banner-viewport banner-viewport-loading" />;
  }

  if (error || slides.length === 0) {
    return (
      <div className="banner-viewport banner-viewport-empty">
        <p className="slide-description">{error ?? 'No banner slides available.'}</p>
      </div>
    );
  }

  const activeSlide = slides[currentIdx];
  const nextSlide = slides[(currentIdx + 1) % slides.length];

  return (
    <div className="banner-viewport">
      {/* 1. Background Image sourced from the active slide fetched from the database */}
      <div
        className={`hero-bg-layer ${isTransitioning ? 'hero-bg-transitioning' : 'hero-bg-active'}`}
        style={{ backgroundImage: `url(${activeSlide.bgImage})` }}
      />

      {/* Vignette Overlay Shadow Gradients */}
      <div className="vignette-overlay-radial" />
      <div className="vignette-overlay-linear" />

      {/* 2. Giant typography layer sitting visually behind pyramid peaks */}
      <div className="hero-title-container">
        <h1 className={`hero-title-text ${isTransitioning ? 'hero-title-transitioning' : 'hero-title-active'}`}>
          {activeSlide.country}
        </h1>
      </div>
      <div />

      {/* 3. Navigation Controls and Metrics Row */}
      <div className="bottom-panel-grid">
        {/* Left: Interactive statistics, description, and "Book Now" CTA */}
        <div className="details-column">
          <div className="metrics-row">
            <div>
              <div className="metric-number">{activeSlide.stats.travelers}</div>
              <div className="metric-label">Happy travelers</div>
            </div>
            <div>
              <div className="metric-number">{activeSlide.stats.tours}</div>
              <div className="metric-label">Custom tour</div>
            </div>
            <div>
              <div className="metric-number">{activeSlide.stats.stays}</div>
              <div className="metric-label">Arranged stays</div>
            </div>
          </div>

          <div className="action-row">
            <div className="cta-button-group">
              <button className="btn-book-now">Book now</button>
              <div className="arrow-circle-btn">
                <ArrowUpRight className="h-5 w-5" />
              </div>
            </div>
            <p className="slide-description">{activeSlide.description}</p>
          </div>
        </div>

        {/* Right: Interactive Glassmorphic Thumbnail Widget */}
        <div className="slider-column">
          <div onClick={goToNextSlide} className="glass-slider-card">
            <div className="slider-footer">
              <span className="slider-index-counter">
                {currentIdx + 1}/0{slides.length}
              </span>
              <div className="progress-dots-row">
                {slides.map((slide, idx) => (
                  <div
                    key={slide.id}
                    className={`progress-dot ${
                      idx === currentIdx ? 'progress-dot-active' : 'progress-dot-inactive'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}