'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ChevronDown, LogIn, UserPlus, LogOut, User } from 'lucide-react';
import { setAccessToken, authApi } from '@/lib/api';

export default function Navbar() {
  const router = useRouter();
  const [user, setUser] = useState<{ username: string; profilePic?: string } | null>(null);

  // 1. On mount, check if a user is logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('accessToken');
    
    if (storedUser && token) {
      setUser(JSON.parse(storedUser));
      setAccessToken(token); // Ensure the API layer knows the token
    }
  }, []);

  // 2. Handle Logout
  const handleLogout = async () => {
    try {
      // Optional: Tell the backend we are logging out
      await authApi.logout();
    } catch (err) {
      console.error("Logout error:", err);
    } finally {
      // Clear everything
      localStorage.removeItem('accessToken');
      localStorage.removeItem('user');
      setAccessToken(null);
      setUser(null);
      router.push('/'); // Redirect to home
    }
  };

  return (
    <header className="brand-header">
      <Link href="/" className="brand-logo">
        Wagha<span>.</span>
      </Link>

      {/* <nav className="nav-capsule">
        <button className="nav-link">
          <span>Trips</span>
          <ChevronDown style={{ height: '16px', width: '16px', opacity: 0.7 }} />
        </button>
        <Link href="/about" className="nav-link">About</Link>
        <Link href="/host" className="nav-link-host">Become a Host</Link>
      </nav> */}

      <div className="auth-actions-group">
        {user ? (
          /* --- LOGGED IN STATE --- */
          <div className="user-profile-group">
            <span className="user-greeting">Hi, {user.username}</span>
            
            <div className="user-avatar-wrapper">
              {user.profilePic ? (
                <img src={user.profilePic} alt="Profile" className="user-avatar-img" />
              ) : (
                <div className="user-avatar-placeholder">
                  <User size={16} />
                </div>
              )}
            </div>

            <button onClick={handleLogout} className="btn-logout-icon" title="Sign out">
              <LogOut size={18} />
            </button>
          </div>
        ) : (
          /* --- LOGGED OUT STATE --- */
          <>
            <Link href="/login" className="auth-btn-login">
              <LogIn style={{ height: '16px', width: '16px', marginRight: '4px', opacity: 0.8 }} />
              <span>Login</span>
            </Link>
            <Link href="/signup" className="auth-btn-signup">
              <UserPlus style={{ height: '16px', width: '16px', marginRight: '4px' }} />
              <span>Sign up</span>
            </Link>
          </>
        )}
      </div>
    </header>
  );
}