"use client";

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle, Lock } from 'lucide-react';
import { useRouter } from 'next/navigation';
import styles from './SinaiJourney.module.css';
import { mediaUrl } from '@/lib/api';

const STEPS = [
  {
    day: "01",
    title: "The Gateway",
    desc: "Arrival in Sharm El Sheikh. We transfer to the edge of the Nabq Protectorate for a sunset dinner.",
    img: mediaUrl("/uploads/images/pexels-mjlo-32622906.jpg")
  },
  {
    day: "02",
    title: "Midnight Ascent",
    desc: "Climb the 3,750 Steps of Penitence to the summit of Mt. Sinai for a sunrise above the clouds.",
    img: mediaUrl("/uploads/images/pexels-mjlo-35508963.jpg")
  },
  {
    day: "03",
    title: "Canyon Labyrinth",
    desc: "Trek through the Colored Canyon, where natural oxidation has painted the rocks in vivid hues.",
    img: mediaUrl("/uploads/images/pexels-mohamed-elshiekh-1591303-29231907.jpg")
  }
];

export default function SinaiJourney() {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Check authentication status on component mount
  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  const handleBooking = () => {
    if (isLoggedIn) {
      // User is logged in, send them directly to the booking page
      router.push('/booking');
    } else {
      // User is not logged in, send them to login and tell login to return to booking
      router.push('/login?redirect=/booking');
    }
  };

  return (
    <div className={styles.mainContainer}>
      {/* Hero Section */}
      <section className={styles.hero}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <span className={styles.heroLabel}>Private Expedition</span>
          <h1 className={styles.heroTitle}>SINAI<span className={styles.heroDot}>.</span></h1>
        </motion.div>
      </section>

      {/* Program Journey Steps */}
      {STEPS.map((step, index) => (
        <div key={index} className={styles.stepSection}>
          <div className={styles.imageSide}>
            <motion.div 
              className={styles.imageWrapper}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <img src={step.img} alt={step.title} className={styles.stepImage} />
            </motion.div>
          </div>

          <div className={styles.textSide}>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className={styles.dayNumber}>{step.day}</span>
              <h2 className={styles.stepTitle}>{step.title}</h2>
              <p className={styles.stepDescription}>{step.desc}</p>
            </motion.div>
          </div>
        </div>
      ))}

      {/* Final Summary & CTA Section */}
      <section className={styles.finalSection}>
        <div className={styles.summaryContent}>
          <h2 className={styles.summaryTitle}>Full Expedition Program</h2>
          
          <div className={styles.grid}>
            {/* List of features */}
            <div>
              <ul className={styles.itineraryList}>
                <li className={styles.itineraryItem}>
                  <CheckCircle size={20} color="#0066cc"/> 7 Days Professional Guiding
                </li>
                <li className={styles.itineraryItem}>
                  <CheckCircle size={20} color="#0066cc"/> All Cultural & Security Permits
                </li>
                <li className={styles.itineraryItem}>
                  <CheckCircle size={20} color="#0066cc"/> Luxury Desert Tenting & Lodge
                </li>
                <li className={styles.itineraryItem}>
                  <CheckCircle size={20} color="#0066cc"/> Full Board: Organic Local Meals
                </li>
              </ul>
            </div>

            {/* Pricing and Booking Card */}
            <div className={styles.ctaCard}>
              <div className={styles.price}>1,850 EGP</div>
              <button className={styles.bookButton} onClick={handleBooking}>
                {isLoggedIn ? "Reserve Spot" : "Sign in to Book"}
                {isLoggedIn ? <ArrowRight size={20} /> : <Lock size={18} />}
              </button>
              <p style={{ color: '#86868b', fontSize: '0.8rem', marginTop: '1rem', textAlign: 'center' }}>
                All-inclusive price excluding international flights.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}